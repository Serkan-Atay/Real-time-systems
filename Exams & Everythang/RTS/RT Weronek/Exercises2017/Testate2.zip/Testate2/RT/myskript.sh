#!/home/student/binf/orlova-k/RT/

aufg3a A 100000000 10 5 & 
aufg3b B 100000000 10 5 & 
aufg3c C 100000000 10 5 & 


