 #!/bin/bash
./myprog0 a 475000000 10 10.0 &
./myprog1 b 475000000 10 10.0 &
./myprog2 c 475000000 10 10.0 &
./myprog3 d 475000000 10 10.0 &

